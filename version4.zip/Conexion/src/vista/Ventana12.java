// src/vista/Ventana12.java
package vista;

import java.awt.*;
import javax.swing.*;
import modelo.DocumentFullData;

public class Ventana12 extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public Ventana12(DocumentFullData doc) {
        setTitle(doc.getTitulo());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 500);
        contentPane = new JPanel(null);
        contentPane.setBackground(Color.DARK_GRAY);
        setContentPane(contentPane);

        JLabel lblTitulo = new JLabel("Título:");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblTitulo.setBounds(30, 20, 100, 30);
        contentPane.add(lblTitulo);

        JLabel valTitulo = new JLabel(doc.getTitulo());
        valTitulo.setForeground(Color.WHITE);
        valTitulo.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        valTitulo.setBounds(140, 20, 600, 30);
        contentPane.add(valTitulo);

        JLabel lblAutor = new JLabel("Autor:");
        lblAutor.setForeground(Color.WHITE);
        lblAutor.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblAutor.setBounds(30, 60, 100, 30);
        contentPane.add(lblAutor);

        JLabel valAutor = new JLabel(doc.getAutor());
        valAutor.setForeground(Color.WHITE);
        valAutor.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        valAutor.setBounds(140, 60, 600, 30);
        contentPane.add(valAutor);

        JLabel lblDesc = new JLabel("Descripción:");
        lblDesc.setForeground(Color.WHITE);
        lblDesc.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblDesc.setBounds(30, 100, 120, 30);
        contentPane.add(lblDesc);

        JTextArea valDesc = new JTextArea(doc.getDescripcion());
        valDesc.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        valDesc.setLineWrap(true);
        valDesc.setWrapStyleWord(true);
        valDesc.setEditable(false);
        JScrollPane scrollDesc = new JScrollPane(valDesc);
        scrollDesc.setBounds(140, 100, 600, 100);
        contentPane.add(scrollDesc);

        JLabel lblAnno = new JLabel("Año:");
        lblAnno.setForeground(Color.WHITE);
        lblAnno.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblAnno.setBounds(30, 210, 100, 30);
        contentPane.add(lblAnno);

        JLabel valAnno = new JLabel(String.valueOf(doc.getAnio()));
        valAnno.setForeground(Color.WHITE);
        valAnno.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        valAnno.setBounds(140, 210, 100, 30);
        contentPane.add(valAnno);

        JLabel lblFormato = new JLabel("Formato:");
        lblFormato.setForeground(Color.WHITE);
        lblFormato.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblFormato.setBounds(30, 250, 120, 30);
        contentPane.add(lblFormato);

        JLabel valFormato = new JLabel(doc.getFormato());
        valFormato.setForeground(Color.WHITE);
        valFormato.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        valFormato.setBounds(140, 250, 200, 30);
        contentPane.add(valFormato);

        JLabel lblColeccion = new JLabel("Colección:");
        lblColeccion.setForeground(Color.WHITE);
        lblColeccion.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblColeccion.setBounds(30, 290, 120, 30);
        contentPane.add(lblColeccion);

        JLabel valColeccion = new JLabel(doc.getColeccion());
        valColeccion.setForeground(Color.WHITE);
        valColeccion.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        valColeccion.setBounds(140, 290, 200, 30);
        contentPane.add(valColeccion);

        JLabel lblFecha = new JLabel("Fecha subida:");
        lblFecha.setForeground(Color.WHITE);
        lblFecha.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblFecha.setBounds(30, 330, 140, 30);
        contentPane.add(lblFecha);

        JLabel valFecha = new JLabel(doc.getFechaDeSubida());
        valFecha.setForeground(Color.WHITE);
        valFecha.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        valFecha.setBounds(170, 330, 300, 30);
        contentPane.add(valFecha);

        if (doc.getImagenPath() != null && !doc.getImagenPath().isBlank()) {
            JLabel lblImg = new JLabel(new ImageIcon(doc.getImagenPath()));
            lblImg.setBounds(500, 210, 200, 200); // ajusta según la imagen
            contentPane.add(lblImg);
        }
    }
}
