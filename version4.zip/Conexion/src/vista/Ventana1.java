package vista;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import modelo.ConexionMySQL;

import java.awt.Color;
import java.awt.Cursor;

import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;

public class Ventana1 extends JFrame {

	private final ConexionMySQL conexion;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;


	/**
	 * Create the frame.
	 */
	public Ventana1(ConexionMySQL conexion) {
		this.conexion = conexion;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 785, 440);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(139, 69, 19));
		contentPane.setForeground(new Color(0, 0, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		/////////////////////Titulo 1//////////////////////////////////////
		JLabel titulo_AetasHistoria = new JLabel("Aetas Historia");
		titulo_AetasHistoria.setForeground(Color.WHITE);
		titulo_AetasHistoria.setBounds(285, 45, 300, 60); // Aumenté el ancho y alto del label
		titulo_AetasHistoria.setFont(new Font("Times New Roman", Font.BOLD, 36)); // Cambiamos el tamaño a 36
		contentPane.add(titulo_AetasHistoria);
		/////////////////////Titulo 2//////////////////////////////////////
		JLabel titulo_Acceso = new JLabel("Acceso");
		titulo_Acceso.setForeground(Color.WHITE);
		titulo_Acceso.setBounds(297, 83, 200, 50); // Ajustamos posición y tamaño
		titulo_Acceso.setFont(new Font("Times New Roman", Font.BOLD, 28)); // Tamaño de fuente aumentado
		titulo_Acceso.setHorizontalAlignment(SwingConstants.CENTER); // Centrado horizontal
		titulo_Acceso.setVerticalAlignment(SwingConstants.CENTER); // Centrado vertical
		contentPane.add(titulo_Acceso);
		//////////////////////BOTON 1///////////////////////////////
		JButton boton_Administrador = new JButton("Administrador");
		boton_Administrador.addActionListener(e -> {
			// Acción: abrir Ventana2
			Ventana2 ventana2 = new Ventana2(this.conexion);   // Asegúrate que Ventana2 exista
			ventana2.setVisible(true);           // Mostrar la nueva ventana
			
			// Cerrar esta ventana (Ventana1)
			dispose();
		});
		boton_Administrador.setBounds(317, 143, 145, 62);
		contentPane.add(boton_Administrador);
		
		//////[[Estilo]///////
		boton_Administrador.setForeground(Color.WHITE);
		boton_Administrador.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Administrador.setBackground(new Color(128, 128, 128)); // Un azul bonito
		boton_Administrador.setFocusPainted(false); // Quitar el borde de foco
		boton_Administrador.setBorderPainted(false); // Quitar el borde por defecto
		boton_Administrador.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR)); // Cambiar cursor al pasar
		
		
		//////////////////////BOTON 2///////////////////////////////
		JButton boton_Investigador = new JButton("Investigador");
		boton_Investigador.setForeground(Color.WHITE);
		boton_Investigador.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Investigador.setFocusPainted(false);
		boton_Investigador.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Investigador.setBorderPainted(false);
		boton_Investigador.setBackground(new Color(128, 128, 128));
		boton_Investigador.setBounds(317, 214, 145, 62);
		contentPane.add(boton_Investigador);
		
		//Acción del botón: abrir Ventana6 y cerrar esta ventana
		boton_Investigador.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		Ventana6 ventana6 = new Ventana6();   // Asegúrate de que exista
		ventana6.setVisible(true);           // Mostrar la nueva ventana
		dispose();                           // Cerrar la ventana actual (Ventana1)
		}
		});
				
		
		
		
		
		
		/////////////////////FOTO PERGAMINO///////////////////////////////
		// Cargar y redimensionar la imagen a un tamaño más pequeño y proporcional
		ImageIcon icono = new ImageIcon(getClass().getResource("/Fotos/pergamino1.png"));
		Image img = icono.getImage().getScaledInstance(200, 80, Image.SCALE_SMOOTH); // Tamaño ajustado
		ImageIcon iconoRed = new ImageIcon(img);

		// Crear JLabel con la imagen redimensionada
		// Redimensionar la imagen al tamaño del JLabel (460x250)
		iconoRed = new ImageIcon(icono.getImage().getScaledInstance(460, 250, Image.SCALE_SMOOTH));

		// Crear el JLabel con la imagen ya redimensionada
		JLabel foto1 = new JLabel(iconoRed);
		foto1.setBounds(165, 10, 460, 290); // Ahora la imagen escala con el label
		foto1.setHorizontalAlignment(SwingConstants.CENTER);
		foto1.setVerticalAlignment(SwingConstants.CENTER);

		contentPane.add(foto1);
		
		JLabel fotoFondo = new JLabel("New label");
		fotoFondo.setIcon(new ImageIcon(getClass().getResource("/Fotos/biblioteca.png")));
		fotoFondo.setBounds(-113, -51, 982, 659);
		contentPane.add(fotoFondo);
		
		
		
		
	}
}
