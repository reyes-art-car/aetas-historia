// src/vista/Ventana11.java
package vista;

import java.awt.*;
import java.awt.event.*;
import java.util.List;
import javax.swing.*;

import modelo.ConexionMySQL;
import modelo.DocumentFullData;

public class Ventana11 extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new Ventana11().setVisible(true));
    }

    public Ventana11() {
        setTitle("Listado de Documentos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 480);
        contentPane = new JPanel(null);
        contentPane.setBackground(Color.DARK_GRAY);
        setContentPane(contentPane);

        JLabel header = new JLabel("Documentos Registrados");
        header.setFont(new Font("Times New Roman", Font.BOLD, 36));
        header.setForeground(Color.WHITE);
        header.setBounds(180, 10, 450, 40);
        contentPane.add(header);

        ConexionMySQL conexion = new ConexionMySQL(
            "localhost","3306","root","","aetas_historia"
        );
        if (!conexion.success()) {
            JOptionPane.showMessageDialog(this, "Error de conexión a la BD.");
            return;
        }

        List<DocumentFullData> docs = conexion.getAllDocuments();
        DefaultListModel<String> model = new DefaultListModel<>();
        for (DocumentFullData d : docs) {
            model.addElement(d.getTitulo());
        }

        JList<String> list = new JList<>(model);
        list.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        JScrollPane scroll = new JScrollPane(list);
        scroll.setBounds(34, 80, 700, 300);
        contentPane.add(scroll);

        // Doble clic abre Ventana12
        list.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int idx = list.locationToIndex(e.getPoint());
                    String titulo = model.getElementAt(idx);
                    DocumentFullData full = conexion.getDocumentByTitle(titulo);
                    if (full != null) {
                        new Ventana12(full).setVisible(true);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(
                          null, "No se pudo cargar la información completa."
                        );
                    }
                }
            }
        });

        JButton btnVolver = new JButton("Volver");
        btnVolver.setFont(new Font("Times New Roman", Font.BOLD, 16));
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setBackground(Color.GRAY);
        btnVolver.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnVolver.setBounds(600, 380, 158, 38);
        btnVolver.addActionListener(e -> {
            new Ventana5().setVisible(true);
            dispose();
        });
        contentPane.add(btnVolver);
    }
}
