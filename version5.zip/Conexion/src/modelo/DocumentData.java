// src/modelo/DocumentData.java
package modelo;

/**
 * Contiene la información de un documento:
 * su título y la ruta de la imagen.
 */
public class DocumentData {
    private final String titulo;
    private final String imagenPath;

    public DocumentData(String titulo, String imagenPath) {
        this.titulo = titulo;
        this.imagenPath = imagenPath;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getImagenPath() {
        return imagenPath;
    }
}
