/**
 * 
 */
/**
 * 
 */
module Conexion {
	requires java.desktop;
	requires java.sql;
}