package Proyecto;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JLabel;

public class VentanaAccesoAdministrador extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaAccesoAdministrador frame = new VentanaAccesoAdministrador();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	////////////////////////////////////////////////////FONDO///////////////////////////////////////////////////////////////////////////////////////////////////
	public VentanaAccesoAdministrador() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(192,192,192));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		/////////////////////////////////////////BOTON ACCEDE ADMINISTRADOR/////////////////////////////////////////////////////////////////////////////////////////////////////////
		JButton botonAccedeAdministrador = new JButton("Accede");
		botonAccedeAdministrador.setBounds(172, 161, 115, 42);
		contentPane.add(botonAccedeAdministrador);
		
		//////////////////////////////////////////BOTON REGISTRO ADMINISTRADOR////////////////////////////////////////////////////////////////////////////////////////////////////////
		JButton botonRegistroAdministrador = new JButton("Registrate");
		botonRegistroAdministrador.setBounds(172, 89, 115, 42);
		contentPane.add(botonRegistroAdministrador);
		/////////////////////////////////////TEXTO ADMINISTRADOR/////////////////////////////////////
		JLabel enunciado1_1 = new JLabel("Administrador");
		enunciado1_1.setBounds(142, 26, 181, 53);
		contentPane.add(enunciado1_1);
		//////////////FONTS
	    /////FONTS FUENTES//////
			enunciado1_1.setFont(new Font("Times New Roman",Font.BOLD,18));
			enunciado1_1.setForeground(Color.WHITE);
			enunciado1_1.setHorizontalAlignment(SwingConstants.CENTER);
			contentPane.add(enunciado1_1);
			
			JButton botonRetrocesoventanaPrincipal = new JButton("🢀");
			botonRetrocesoventanaPrincipal.setBounds(10, 211, 55, 42);
			contentPane.add(botonRetrocesoventanaPrincipal);
		
	}

}
