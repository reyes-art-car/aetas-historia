package modelo;

import java.util.ArrayList;
import java.util.List;

public class SignInImpl implements SignInDao {

    private List<Usuario> usuariosRegistrados = new ArrayList<>();
}
