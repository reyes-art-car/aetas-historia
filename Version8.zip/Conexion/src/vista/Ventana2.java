package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import modelo.ConexionMySQL;

import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import java.awt.Cursor;
import javax.swing.ImageIcon;

public class Ventana2 extends JFrame {
	private final ConexionMySQL conexion;
	
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;


	/**
	 * Create the frame.
	 */

	public Ventana2(ConexionMySQL conexion) {
		this.conexion = conexion;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 786, 442);//ESTE ES EL ANCHO DE LA VENTANA COMPLETA//
		contentPane = new JPanel();
		contentPane.setBackground(new Color(139, 69, 19));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		///////////////////// TITULO 1//////////////////////////////////////
		JLabel titulo_AetasHistoria = new JLabel("Aetas Historia");
		titulo_AetasHistoria.setForeground(Color.WHITE);
		titulo_AetasHistoria.setFont(new Font("Times New Roman", Font.BOLD, 36));
		titulo_AetasHistoria.setBounds(253, 10, 300, 60);
		contentPane.add(titulo_AetasHistoria);
		
		///////////////////// TITULO 2//////////////////////////////////////
		JLabel titulo_Administardor = new JLabel("Administrador");
		titulo_Administardor.setForeground(Color.WHITE);
		titulo_Administardor.setFont(new Font("Times New Roman", Font.BOLD, 36));
		titulo_Administardor.setBounds(253, 80, 300, 60);
		contentPane.add(titulo_Administardor);
		
		/////////////////////BOTON REGISTRATE//////////////////////////////////////
		JButton boton_Registrate = new JButton("Registrate");
		boton_Registrate.setForeground(Color.WHITE);
		boton_Registrate.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Registrate.setFocusPainted(false);
		boton_Registrate.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Registrate.setBorderPainted(false);
		boton_Registrate.setBackground(Color.GRAY);
		boton_Registrate.setBounds(291, 169, 145, 62);
		contentPane.add(boton_Registrate);

		// Acción del botón: abrir Ventana3
		boton_Registrate.addActionListener(e -> {
	        Ventana3 ventana3 = new Ventana3(conexion);   // Asegúrate de que exista
	        ventana3.setVisible(true);
	        dispose();
		});
		/////////////////////BOTON ACCEDE//////////////////////////////////////
		JButton boton_Accede = new JButton("Accede");
		boton_Accede.setForeground(Color.WHITE);
		boton_Accede.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Accede.setFocusPainted(false);
		boton_Accede.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Accede.setBorderPainted(false);
		boton_Accede.setBackground(Color.GRAY);
		boton_Accede.setBounds(291, 267, 145, 62);
		contentPane.add(boton_Accede);

		// Acción del botón: abrir Ventana5
		boton_Accede.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        Ventana9 ventana9 = new Ventana9();   // Asegúrate de que exista
		        ventana9.setVisible(true);
		        dispose();
		    }
		});
		
		/////////////////////FOTO 1//////////////////////////////////////
		// Cargar la imagen original
		ImageIcon iconoOriginal = new ImageIcon(getClass().getResource("/Fotos/administrador.png"));

		// Redimensionar la imagen
		Image imgRedimensionada = iconoOriginal.getImage().getScaledInstance(150, 160, Image.SCALE_SMOOTH); // Cambia estos valores según quieras
		ImageIcon iconoRedimensionado = new ImageIcon(imgRedimensionada);

		// Crear el JLabel con la imagen ya redimensionada
		JLabel foto1 = new JLabel(iconoRedimensionado);
		foto1.setBounds(95, 10, 150, 160); // Tamaño del label igual al de la imagen
		foto1.setHorizontalAlignment(SwingConstants.CENTER);
		foto1.setVerticalAlignment(SwingConstants.CENTER);

		contentPane.add(foto1);
		/////////////////////BOTON RETROCESO//////////////////////////////////////
		JButton boton_Retroceso = new JButton("Retroceso");
		boton_Retroceso.setForeground(Color.WHITE);
		boton_Retroceso.setFont(new Font("Arial", Font.BOLD, 16));
		boton_Retroceso.setFocusPainted(false);
		boton_Retroceso.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Retroceso.setBorderPainted(false);
		boton_Retroceso.setBackground(Color.GRAY);
		boton_Retroceso.setBounds(10, 332, 139, 62);
		contentPane.add(boton_Retroceso);
		
		JLabel fotoFondo = new JLabel("New label");
		fotoFondo.setIcon(new ImageIcon(getClass().getResource("/Fotos/biblioteca.png")));
		fotoFondo.setBounds(-118, -34, 929, 666);
		contentPane.add(fotoFondo);

		
	}

}
