package modelo;

import java.awt.EventQueue;
import java.sql.SQLException;

import modelo.ConexionMySQL;
import modelo.DocumentoDaoImpl;
import vista.Ventana1;

public class Main {
	public static void main(String[] args) {
		ConexionMySQL conexion = new ConexionMySQL("localhost", "3306", "root", "", "aetas_historia");
		
		if (conexion.success()) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						Ventana1 frame = new Ventana1(conexion);
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		} else {
			System.out.println("error");
		}
	}
}