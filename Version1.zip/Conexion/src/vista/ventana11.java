package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Cursor;
import javax.swing.UIManager;
import javax.swing.ImageIcon;

public class ventana11 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField rellenar_busqueda;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ventana11 frame = new ventana11();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ventana11() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 785, 440);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel titulo_AetasHistoria = new JLabel("Aetas Historia");
		titulo_AetasHistoria.setForeground(Color.WHITE);
		titulo_AetasHistoria.setFont(new Font("Times New Roman", Font.BOLD, 36));
		titulo_AetasHistoria.setBounds(223, 0, 300, 60);
		contentPane.add(titulo_AetasHistoria);
		
		JLabel subtitulo_AetasHistoria = new JLabel("Aetas Historia");
		subtitulo_AetasHistoria.setForeground(Color.WHITE);
		subtitulo_AetasHistoria.setFont(new Font("Times New Roman", Font.BOLD, 20));
		subtitulo_AetasHistoria.setBounds(354, 43, 300, 60);
		contentPane.add(subtitulo_AetasHistoria);
		
		rellenar_busqueda = new JTextField();
		rellenar_busqueda.setColumns(10);
		rellenar_busqueda.setBounds(510, 66, 226, 19);
		contentPane.add(rellenar_busqueda);
		
		JButton boton_inicio = new JButton("Inicio");
		boton_inicio.setForeground(Color.WHITE);
		boton_inicio.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_inicio.setFocusPainted(false);
		boton_inicio.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_inicio.setBorderPainted(false);
		boton_inicio.setBackground(Color.GRAY);
		boton_inicio.setBounds(0, 113, 158, 38);
		contentPane.add(boton_inicio);
		
		JButton boton_Documentos = new JButton("Documentos");
		boton_Documentos.setForeground(Color.WHITE);
		boton_Documentos.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Documentos.setFocusPainted(false);
		boton_Documentos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Documentos.setBorderPainted(false);
		boton_Documentos.setBackground(Color.GRAY);
		boton_Documentos.setBounds(153, 113, 158, 38);
		contentPane.add(boton_Documentos);
		
		JButton boton_Autores = new JButton("Autores");
		boton_Autores.setForeground(Color.WHITE);
		boton_Autores.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Autores.setFocusPainted(false);
		boton_Autores.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Autores.setBorderPainted(false);
		boton_Autores.setBackground(Color.GRAY);
		boton_Autores.setBounds(309, 113, 158, 38);
		contentPane.add(boton_Autores);
		
		JButton boton_EtapasHistoricas = new JButton("Etapas historicas");
		boton_EtapasHistoricas.setForeground(Color.WHITE);
		boton_EtapasHistoricas.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_EtapasHistoricas.setFocusPainted(false);
		boton_EtapasHistoricas.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_EtapasHistoricas.setBorderPainted(false);
		boton_EtapasHistoricas.setBackground(Color.GRAY);
		boton_EtapasHistoricas.setBounds(467, 113, 158, 38);
		contentPane.add(boton_EtapasHistoricas);
		
		JButton boton_Categorias = new JButton("Categoria");
		boton_Categorias.setForeground(Color.WHITE);
		boton_Categorias.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Categorias.setFocusPainted(false);
		boton_Categorias.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Categorias.setBorderPainted(false);
		boton_Categorias.setBackground(Color.GRAY);
		boton_Categorias.setBounds(624, 113, 158, 38);
		contentPane.add(boton_Categorias);
		
		JPanel panel_Documento1 = new JPanel();
		panel_Documento1.setBackground(UIManager.getColor("Button.foreground"));
		panel_Documento1.setBounds(34, 161, 86, 60);
		contentPane.add(panel_Documento1);
		
		JPanel panel_Documento2 = new JPanel();
		panel_Documento2.setBackground(Color.BLACK);
		panel_Documento2.setBounds(187, 161, 86, 60);
		contentPane.add(panel_Documento2);
		
		JPanel panel_Documento3 = new JPanel();
		panel_Documento3.setBackground(Color.BLACK);
		panel_Documento3.setBounds(351, 161, 86, 60);
		contentPane.add(panel_Documento3);
		
		JPanel panel_Documento4 = new JPanel();
		panel_Documento4.setBackground(Color.BLACK);
		panel_Documento4.setBounds(505, 161, 86, 60);
		contentPane.add(panel_Documento4);
		
		JPanel panel_Documento5 = new JPanel();
		panel_Documento5.setBackground(Color.BLACK);
		panel_Documento5.setBounds(662, 161, 86, 60);
		contentPane.add(panel_Documento5);
		
		JPanel panel_Documento6 = new JPanel();
		panel_Documento6.setBackground(Color.BLACK);
		panel_Documento6.setBounds(34, 285, 86, 60);
		contentPane.add(panel_Documento6);
		
		JPanel panel_Documento7 = new JPanel();
		panel_Documento7.setBackground(Color.BLACK);
		panel_Documento7.setBounds(187, 285, 86, 60);
		contentPane.add(panel_Documento7);
		
		JPanel panel_Documento8 = new JPanel();
		panel_Documento8.setBackground(Color.BLACK);
		panel_Documento8.setBounds(351, 285, 86, 60);
		contentPane.add(panel_Documento8);
		
		JPanel panel_Documento9 = new JPanel();
		panel_Documento9.setBackground(Color.BLACK);
		panel_Documento9.setBounds(505, 285, 86, 60);
		contentPane.add(panel_Documento9);
		
		JPanel panel_Documento11 = new JPanel();
		panel_Documento11.setBackground(Color.BLACK);
		panel_Documento11.setBounds(662, 285, 86, 60);
		contentPane.add(panel_Documento11);
		
		JLabel texto_panel_documento1 = new JLabel("Documento 1");
		texto_panel_documento1.setForeground(Color.WHITE);
		texto_panel_documento1.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento1.setBounds(44, 214, 300, 60);
		contentPane.add(texto_panel_documento1);
		
		JLabel texto_panel_documento2 = new JLabel("Documento 2");
		texto_panel_documento2.setForeground(Color.WHITE);
		texto_panel_documento2.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento2.setBounds(197, 215, 300, 60);
		contentPane.add(texto_panel_documento2);
		
		JLabel texto_panel_documento5 = new JLabel("Documento 5");
		texto_panel_documento5.setForeground(Color.WHITE);
		texto_panel_documento5.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento5.setBounds(672, 215, 252, 60);
		contentPane.add(texto_panel_documento5);
		
		JLabel texto_panel_documento3 = new JLabel("Documento 3");
		texto_panel_documento3.setForeground(Color.WHITE);
		texto_panel_documento3.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento3.setBounds(354, 215, 300, 60);
		contentPane.add(texto_panel_documento3);
		
		JLabel texto_panel_documento4 = new JLabel("Documento 4");
		texto_panel_documento4.setForeground(Color.WHITE);
		texto_panel_documento4.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento4.setBounds(515, 214, 300, 60);
		contentPane.add(texto_panel_documento4);
		
		JLabel texto_panel_documento6 = new JLabel("Documento 6");
		texto_panel_documento6.setForeground(Color.WHITE);
		texto_panel_documento6.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento6.setBounds(44, 342, 300, 60);
		contentPane.add(texto_panel_documento6);
		
		JLabel texto_panel_documento7 = new JLabel("Documento 7");
		texto_panel_documento7.setForeground(Color.WHITE);
		texto_panel_documento7.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento7.setBounds(197, 343, 300, 60);
		contentPane.add(texto_panel_documento7);
		
		JLabel texto_panel_documento10 = new JLabel("Documento 10");
		texto_panel_documento10.setForeground(Color.WHITE);
		texto_panel_documento10.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento10.setBounds(672, 343, 252, 60);
		contentPane.add(texto_panel_documento10);
		
		JLabel texto_panel_documento8 = new JLabel("Documento 8");
		texto_panel_documento8.setForeground(Color.WHITE);
		texto_panel_documento8.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento8.setBounds(354, 343, 300, 60);
		contentPane.add(texto_panel_documento8);
		
		JLabel texto_panel_documento9 = new JLabel("Documento 9");
		texto_panel_documento9.setForeground(Color.WHITE);
		texto_panel_documento9.setFont(new Font("Times New Roman", Font.BOLD, 10));
		texto_panel_documento9.setBounds(515, 342, 300, 60);
		contentPane.add(texto_panel_documento9);
		
		JLabel fotoFondo = new JLabel("New label");
		fotoFondo.setIcon(new ImageIcon("C:\\Users\\manzano\\Desktop\\FOTOS\\biblioteca.png"));
		fotoFondo.setBounds(-131, -14, 913, 556);
		contentPane.add(fotoFondo);
	}
}
