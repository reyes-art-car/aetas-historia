package vista;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import modelo.ConexionMySQL;

public class Ventana5 extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField rellenar_NombreDelDocumento;
    private JTextField rellenar_NombreDelAutor;
    private JTextField relelnar_Descripcion;
    private JTextField rellenar_Ano;
    private JTextField rellenar_Coleccion;
    private JTextField rellenar_Formato;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Ventana5 frame = new Ventana5();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public Ventana5() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 440);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Título
        JLabel titulo = new JLabel("Crear Documento");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("Times New Roman", Font.BOLD, 36));
        titulo.setBounds(223, 10, 350, 60);
        contentPane.add(titulo);

        // Etiquetas de campos
        JLabel lblNombre = new JLabel("Nombre del documento");
        lblNombre.setForeground(Color.WHITE);
        lblNombre.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblNombre.setBounds(10, 168, 300, 60);
        contentPane.add(lblNombre);

        JLabel lblAutor = new JLabel("Nombre del Autor");
        lblAutor.setForeground(Color.WHITE);
        lblAutor.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblAutor.setBounds(10, 204, 300, 60);
        contentPane.add(lblAutor);

        JLabel lblDescripcion = new JLabel("Descripcion");
        lblDescripcion.setForeground(Color.WHITE);
        lblDescripcion.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblDescripcion.setBounds(10, 243, 300, 60);
        contentPane.add(lblDescripcion);

        JLabel lblAno = new JLabel("Año");
        lblAno.setForeground(Color.WHITE);
        lblAno.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblAno.setBounds(10, 274, 300, 60);
        contentPane.add(lblAno);

        JLabel lblColeccion = new JLabel("Coleccion");
        lblColeccion.setForeground(Color.WHITE);
        lblColeccion.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblColeccion.setBounds(10, 313, 300, 60);
        contentPane.add(lblColeccion);

        JLabel lblFormato = new JLabel("Formato");
        lblFormato.setForeground(Color.WHITE);
        lblFormato.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblFormato.setBounds(10, 355, 300, 60);
        contentPane.add(lblFormato);

        // Campos de texto
        rellenar_NombreDelDocumento = new JTextField();
        rellenar_NombreDelDocumento.setBounds(354, 191, 226, 19);
        contentPane.add(rellenar_NombreDelDocumento);

        rellenar_NombreDelAutor = new JTextField();
        rellenar_NombreDelAutor.setBounds(354, 227, 226, 19);
        contentPane.add(rellenar_NombreDelAutor);

        relelnar_Descripcion = new JTextField();
        relelnar_Descripcion.setBounds(354, 266, 226, 19);
        contentPane.add(relelnar_Descripcion);

        rellenar_Ano = new JTextField();
        rellenar_Ano.setBounds(354, 297, 226, 19);
        contentPane.add(rellenar_Ano);

        rellenar_Coleccion = new JTextField();
        rellenar_Coleccion.setBounds(354, 336, 226, 19);
        contentPane.add(rellenar_Coleccion);

        rellenar_Formato = new JTextField();
        rellenar_Formato.setBounds(354, 380, 226, 19);
        contentPane.add(rellenar_Formato);

        // Botón Crear Documento
        JButton btnCrear = new JButton("Crear Documento");
        btnCrear.setForeground(Color.WHITE);
        btnCrear.setFont(new Font("Times New Roman", Font.BOLD, 16));
        btnCrear.setFocusPainted(false);
        btnCrear.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnCrear.setBorderPainted(false);
        btnCrear.setBackground(Color.GRAY);
        btnCrear.setBounds(600, 380, 158, 38);
        contentPane.add(btnCrear);

        // Acción al pulsar el botón o Enter
        btnCrear.addActionListener((ActionEvent e) -> {
            String tituloDoc = rellenar_NombreDelDocumento.getText();
            String autor = rellenar_NombreDelAutor.getText();
            String descripcion = relelnar_Descripcion.getText();
            String anioStr = rellenar_Ano.getText();
            String coleccion = rellenar_Coleccion.getText();
            String formato = rellenar_Formato.getText();

            // Validar que el año sea numérico
            int anio;
            try {
                anio = Integer.parseInt(anioStr);
            } catch (NumberFormatException nfe) {
                JOptionPane.showMessageDialog(this, "El campo Año debe ser un número válido.");
                return;
            }

            // Formatear fecha y hora para DATETIME (`YYYY-MM-DD HH:MM:SS`)
            String fechaHora = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            // Conexión a la BD: ajusta usuario/password según tu configuración
            ConexionMySQL conexion = new ConexionMySQL(
                "localhost", "3306",
                "root", "",
                "aetas_historia"
            );

            if (!conexion.success()) {
                JOptionPane.showMessageDialog(this, "Error de conexión a la base de datos.");
                return;
            }

            // Llamada con int para año
            boolean exito = conexion.añadirDocumento(
                tituloDoc,
                descripcion,
                autor,
                anio, // pasar entero directamente
                formato,
                coleccion,
                fechaHora
            );

            if (exito) {
                JOptionPane.showMessageDialog(this, "Documento guardado correctamente en MySQL.");
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el documento.");
            }
        });

        // Permitir pulsar Enter para crear
        getRootPane().setDefaultButton(btnCrear);

        // Fondo de la ventana
        JLabel fondo = new JLabel("");
        fondo.setIcon(new ImageIcon(getClass().getResource("/Fotos/biblioteca.png")));
        fondo.setBounds(-13, 0, 795, 501);
        contentPane.add(fondo);
    }
}
