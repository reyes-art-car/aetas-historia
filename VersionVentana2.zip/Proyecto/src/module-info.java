/**
 * 
 */
/**
 * 
 */
module Proyecto {
	requires java.desktop;
}