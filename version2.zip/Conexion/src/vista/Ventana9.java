package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Cursor;

public class Ventana9 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField rellenar_Correo;
	private JTextField rellenar_contrasena;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana9 frame = new Ventana9();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana9() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 785, 440);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel titulo_AetasHistoria = new JLabel("Aetas Historia");
		titulo_AetasHistoria.setForeground(Color.WHITE);
		titulo_AetasHistoria.setFont(new Font("Times New Roman", Font.BOLD, 36));
		titulo_AetasHistoria.setBounds(243, 10, 300, 60);
		contentPane.add(titulo_AetasHistoria);
		
		JLabel titulo_AccedeConTuCorreoElectronico = new JLabel("Accede con tu correo electronico");
		titulo_AccedeConTuCorreoElectronico.setForeground(Color.WHITE);
		titulo_AccedeConTuCorreoElectronico.setFont(new Font("Times New Roman", Font.BOLD, 20));
		titulo_AccedeConTuCorreoElectronico.setBounds(214, 61, 300, 60);
		contentPane.add(titulo_AccedeConTuCorreoElectronico);
		
		JLabel titulo_Correo = new JLabel("Correo");
		titulo_Correo.setForeground(Color.WHITE);
		titulo_Correo.setFont(new Font("Times New Roman", Font.BOLD, 20));
		titulo_Correo.setBounds(299, 128, 300, 60);
		contentPane.add(titulo_Correo);
		
		JLabel titulo_Contrasena = new JLabel("Contraseña");
		titulo_Contrasena.setForeground(Color.WHITE);
		titulo_Contrasena.setFont(new Font("Times New Roman", Font.BOLD, 20));
		titulo_Contrasena.setBounds(299, 223, 300, 60);
		contentPane.add(titulo_Contrasena);
		
		rellenar_Correo = new JTextField();
		rellenar_Correo.setColumns(10);
		rellenar_Correo.setBounds(149, 186, 415, 27);
		contentPane.add(rellenar_Correo);
		
		rellenar_contrasena = new JTextField();
		rellenar_contrasena.setColumns(10);
		rellenar_contrasena.setBounds(149, 302, 415, 27);
		contentPane.add(rellenar_contrasena);
		
		JButton boton_Accede = new JButton("Accede");
		boton_Accede.setForeground(Color.WHITE);
		boton_Accede.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Accede.setFocusPainted(false);
		boton_Accede.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Accede.setBorderPainted(false);
		boton_Accede.setBackground(Color.GRAY);
		boton_Accede.setBounds(270, 339, 158, 38);
		contentPane.add(boton_Accede);

		// Acción del botón: abrir Ventana11
		boton_Accede.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        ventana11 ventana11 = new ventana11();   // Asegúrate de que exista
		        ventana11.setVisible(true);             // Mostrar la nueva ventana
		    }
		});
		
		JLabel fotoFondo = new JLabel("New label");
		fotoFondo.setIcon(new ImageIcon(getClass().getResource("/Fotos/biblioteca.png")));
		fotoFondo.setBounds(-64, 0, 925, 476);
		contentPane.add(fotoFondo);
	}

}
