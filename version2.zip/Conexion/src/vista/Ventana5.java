// src/vista/Ventana5.java
package vista;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import modelo.ConexionMySQL;

public class Ventana5 extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtTitulo, txtAutor, txtDescripcion, txtAnio, txtColeccion, txtFormato;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new Ventana5().setVisible(true));
    }

    public Ventana5() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 440);
        contentPane = new JPanel(null);
        contentPane.setBackground(Color.DARK_GRAY);
        setContentPane(contentPane);

        // Labels + campos
        addLabel("Nombre del documento", 10,168);
        addLabel("Nombre del Autor",     10,204);
        addLabel("Descripción",          10,243);
        addLabel("Año",                  10,274);
        addLabel("Colección",            10,313);
        addLabel("Formato",              10,355);

        txtTitulo      = addTF(354,191);
        txtAutor       = addTF(354,227);
        txtDescripcion = addTF(354,266);
        txtAnio        = addTF(354,297);
        txtColeccion   = addTF(354,336);
        txtFormato     = addTF(354,380);

        // Botón Crear Documento
        JButton btnCrear = makeButton("Crear Documento", 600,380);
        contentPane.add(btnCrear);
        btnCrear.addActionListener((ActionEvent e) -> {
            String titulo      = txtTitulo.getText().trim();
            String autor       = txtAutor.getText().trim();
            String descripcion = txtDescripcion.getText().trim();
            String anioStr     = txtAnio.getText().trim();
            String coleccion   = txtColeccion.getText().trim();
            String formato     = txtFormato.getText().trim();

            int anio;
            try { anio = Integer.parseInt(anioStr); }
            catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "El campo Año debe ser numérico."); 
                return;
            }

            String fechaHora = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            ConexionMySQL conexion = new ConexionMySQL(
                "localhost","3306","root","","aetas_historia"
            );
            if (!conexion.success()) {
                JOptionPane.showMessageDialog(this, "Error de conexión a la BD.");
                return;
            }

            boolean ok = conexion.añadirDocumento(
                titulo, descripcion, autor, anio,
                formato, coleccion, fechaHora
            );
            if (!ok) {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el documento.");
                return;
            }

            // Si se guardó bien, abrimos Ventana11 para listar todos
            new Ventana11().setVisible(true);
            dispose();
        });

        getRootPane().setDefaultButton(btnCrear);
    }

    private void addLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lbl.setBounds(x, y, 300, 60);
        contentPane.add(lbl);
    }

    private JTextField addTF(int x, int y) {
        JTextField tf = new JTextField();
        tf.setBounds(x, y, 226, 19);
        contentPane.add(tf);
        return tf;
    }

    private JButton makeButton(String txt, int x, int y) {
        JButton b = new JButton(txt);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Times New Roman", Font.BOLD, 16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorderPainted(false);
        b.setBackground(Color.GRAY);
        b.setBounds(x, y, 158, 38);
        return b;
    }
}
