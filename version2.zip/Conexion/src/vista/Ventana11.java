// src/vista/Ventana11.java
package vista;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Color;
import java.awt.Cursor;
import java.util.List;
import javax.swing.*;
import modelo.ConexionMySQL;

public class Ventana11 extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel[] labelsDocumentos;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new Ventana11().setVisible(true));
    }

    public Ventana11() {
        setTitle("Listado de Documentos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 440);
        contentPane = new JPanel(null);
        contentPane.setBackground(Color.DARK_GRAY);
        setContentPane(contentPane);

        // Título
        JLabel header = new JLabel("Documentos Registrados");
        header.setFont(new Font("Times New Roman", Font.BOLD, 36));
        header.setForeground(Color.WHITE);
        header.setBounds(200, 10, 400, 60);
        contentPane.add(header);

        // Creamos 10 etiquetas donde se mostrarán los títulos
        labelsDocumentos = new JLabel[10];
        int x = 34, y = 100;
        for (int i = 0; i < labelsDocumentos.length; i++) {
            labelsDocumentos[i] = new JLabel("Vacío");
            labelsDocumentos[i].setFont(new Font("Times New Roman", Font.BOLD, 16));
            labelsDocumentos[i].setForeground(Color.WHITE);
            labelsDocumentos[i].setBounds(x, y, 200, 30);
            contentPane.add(labelsDocumentos[i]);

            x += 350; // separa columnas
            if ((i + 1) % 2 == 0) {
                x = 34;   // vuelve a la primera columna
                y += 50;  // baja fila
            }
        }

        // Botón para volver (opcional)
        JButton btnVolver = new JButton("Volver");
        btnVolver.setFont(new Font("Times New Roman", Font.BOLD, 16));
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setBackground(Color.GRAY);
        btnVolver.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnVolver.setBounds(600, 380, 158, 38);
        contentPane.add(btnVolver);
        btnVolver.addActionListener(e -> {
            new Ventana5().setVisible(true);
            dispose();
        });

        // Cargar datos de la BD y poblar etiquetas
        cargarTitulos();
    }

    private void cargarTitulos() {
        ConexionMySQL conexion = new ConexionMySQL(
            "localhost", "3306", "root", "", "aetas_historia"
        );
        if (!conexion.success()) {
            JOptionPane.showMessageDialog(this, "Error de conexión a la BD.");
            return;
        }
        List<String> titulos = conexion.getAllDocumentTitles();
        for (int i = 0; i < labelsDocumentos.length && i < titulos.size(); i++) {
            labelsDocumentos[i].setText((i+1) + ". " + titulos.get(i));
        }
    }
}
