package vista;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.ImageIcon;

public class Ventana12 extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField rellenar_buscador;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Ventana12 frame = new Ventana12();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Ventana12() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 785, 440);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton boton_Inicio = new JButton("Inicio");
		boton_Inicio.setForeground(Color.WHITE);
		boton_Inicio.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Inicio.setFocusPainted(false);
		boton_Inicio.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Inicio.setBorderPainted(false);
		boton_Inicio.setBackground(Color.GRAY);
		boton_Inicio.setBounds(0, 123, 158, 38);
		contentPane.add(boton_Inicio);
		
		JButton boton_Documentos = new JButton("Documentos");
		boton_Documentos.setForeground(Color.WHITE);
		boton_Documentos.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Documentos.setFocusPainted(false);
		boton_Documentos.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Documentos.setBorderPainted(false);
		boton_Documentos.setBackground(Color.GRAY);
		boton_Documentos.setBounds(153, 123, 158, 38);
		contentPane.add(boton_Documentos);
		
		JButton boton_Autores = new JButton("Autores");
		boton_Autores.setForeground(Color.WHITE);
		boton_Autores.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Autores.setFocusPainted(false);
		boton_Autores.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Autores.setBorderPainted(false);
		boton_Autores.setBackground(Color.GRAY);
		boton_Autores.setBounds(309, 123, 158, 38);
		contentPane.add(boton_Autores);
		
		JButton boton_EtapasHistoricas = new JButton("Etapas historicas");
		boton_EtapasHistoricas.setForeground(Color.WHITE);
		boton_EtapasHistoricas.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_EtapasHistoricas.setFocusPainted(false);
		boton_EtapasHistoricas.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_EtapasHistoricas.setBorderPainted(false);
		boton_EtapasHistoricas.setBackground(Color.GRAY);
		boton_EtapasHistoricas.setBounds(467, 123, 158, 38);
		contentPane.add(boton_EtapasHistoricas);
		
		JButton boton_Categoria = new JButton("Categoria");
		boton_Categoria.setForeground(Color.WHITE);
		boton_Categoria.setFont(new Font("Times New Roman", Font.BOLD, 16));
		boton_Categoria.setFocusPainted(false);
		boton_Categoria.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		boton_Categoria.setBorderPainted(false);
		boton_Categoria.setBackground(Color.GRAY);
		boton_Categoria.setBounds(624, 123, 158, 38);
		contentPane.add(boton_Categoria);
		
		JLabel subtitulo_AetasHistoria = new JLabel("Aetas Historia");
		subtitulo_AetasHistoria.setForeground(Color.WHITE);
		subtitulo_AetasHistoria.setFont(new Font("Times New Roman", Font.BOLD, 20));
		subtitulo_AetasHistoria.setBounds(354, 53, 300, 60);
		contentPane.add(subtitulo_AetasHistoria);
		
		rellenar_buscador = new JTextField();
		rellenar_buscador.setColumns(10);
		rellenar_buscador.setBounds(510, 76, 226, 19);
		contentPane.add(rellenar_buscador);
		
		JLabel titulo_AetasHistoria = new JLabel("Aetas Historia");
		titulo_AetasHistoria.setForeground(Color.WHITE);
		titulo_AetasHistoria.setFont(new Font("Times New Roman", Font.BOLD, 36));
		titulo_AetasHistoria.setBounds(223, 10, 300, 60);
		contentPane.add(titulo_AetasHistoria);
		
		JLabel documento7 = new JLabel("Documento 7");
		documento7.setForeground(Color.WHITE);
		documento7.setFont(new Font("Times New Roman", Font.BOLD, 20));
		documento7.setBounds(297, 151, 300, 60);
		contentPane.add(documento7);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setBounds(243, 210, 244, 183);
		contentPane.add(panel);
		
		JLabel fotoFondo = new JLabel("New label");
		fotoFondo.setIcon(new ImageIcon("C:\\Users\\manzano\\Desktop\\FOTOS\\biblioteca.png"));
		fotoFondo.setBounds(-58, 0, 840, 489);
		contentPane.add(fotoFondo);
	}

}
