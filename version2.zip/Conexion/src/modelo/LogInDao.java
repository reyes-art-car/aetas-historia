package modelo;

public interface LogInDao {
public boolean LogIn (String username, String password);

}
