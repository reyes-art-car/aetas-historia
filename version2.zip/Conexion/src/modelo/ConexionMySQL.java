// src/modelo/ConexionMySQL.java
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ConexionMySQL {
    private Connection conexion;

    /** 
     * Constructor: abre la conexión JDBC 
     */
    public ConexionMySQL(String host, String port, String user, String pass, String bd) {
        String url = "jdbc:mysql://" + host + ":" + port
            + "/" + bd + "?useSSL=false&serverTimezone=UTC";
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            this.conexion = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            this.conexion = null;
        }
    }

    /** Comprueba si la conexión está viva */
    public boolean success() {
        return this.conexion != null;
    }

    /**
     * Comprueba si ya existe un usuario con ese nombre.
     */
    public boolean userExist(String username) {
        String SQL = "SELECT nombre FROM usuario WHERE nombre = ?";
        try (PreparedStatement stmt = conexion.prepareStatement(SQL)) {
            stmt.setString(1, username);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Inserta un nuevo usuario en la tabla `usuario`.
     */
    public boolean register(String nombre, String email, String contraseña) {
        String SQL = """
            INSERT INTO usuario(
              nombre, email, tipo_de_usuario_id_tipo_de_usuario, contraseña
            ) VALUES (?, ?, 2, ?)
            """;
        try (PreparedStatement stmt = conexion.prepareStatement(SQL)) {
            stmt.setString(1, nombre);
            stmt.setString(2, email);
            stmt.setString(3, contraseña);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Inserta un documento en la tabla `documento`.
     */
    public boolean añadirDocumento(
        String titulo,
        String descripcion,
        String autor,
        int anio,
        String formato,
        String coleccion,
        String fechaDeSubida
    ) {
        String SQL = """
            INSERT INTO documento(
              titulo, descripcion, autor, anio,
              formato, coleccion, fecha_de_subida
            ) VALUES (?,?,?,?,?,?,?)
            """;
        try (PreparedStatement stmt = conexion.prepareStatement(SQL)) {
            stmt.setString(1, titulo);
            stmt.setString(2, descripcion);
            stmt.setString(3, autor);
            stmt.setInt   (4, anio);
            stmt.setString(5, formato);
            stmt.setString(6, coleccion);
            stmt.setString(7, fechaDeSubida);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Recupera todos los títulos de los documentos, ordenados por id_documento asc.
     */
    public List<String> getAllDocumentTitles() {
        List<String> titulos = new ArrayList<>();
        String SQL = "SELECT titulo FROM documento ORDER BY id_documento";
        try (PreparedStatement stmt = conexion.prepareStatement(SQL);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                titulos.add(rs.getString("titulo"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return titulos;
    }
}
