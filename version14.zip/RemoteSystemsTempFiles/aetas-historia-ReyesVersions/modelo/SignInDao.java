package modelo;

public interface SignInDao {
 public boolean SignIn (String nickname, String nombre,String email, String password);
}
