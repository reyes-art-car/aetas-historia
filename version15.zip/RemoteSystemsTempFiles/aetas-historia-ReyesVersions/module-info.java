/**
 * 
 */
/**
 * 
 */
module aetas_historia {
	requires java.desktop;
	requires java.sql;
}