package vista;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import modelo.ConexionMySQL;

/**
 * Ventana principal tras login: permite gestionar documentos.
 */
public class MainMenuWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    /** Conexión centralizada a la base de datos */
    private final ConexionMySQL conexion;
    private JPanel contentPane;

    /**
     * Constructor.
     * @param conexion Instancia de conexión a la base de datos
     */
    public MainMenuWindow(ConexionMySQL conexion) {
        this.conexion = conexion;

        // --- BLOQUE 1: Configuración de ventana y panel principal ---
        setTitle("Aetas Historia - Gestión de Documentos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 440);

        contentPane = new JPanel(null);
        contentPane.setBackground(new Color(139, 69, 19));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        // --- BLOQUE 2: Imagen de fondo (reordenada al fondo visual luego) ---
        JLabel fotoFondo = new JLabel(new ImageIcon(
            getClass().getResource("/Fotos/biblioteca.png")
        ));
        fotoFondo.setBounds(-97, 0, 935, 574);
        contentPane.add(fotoFondo);

        // --- BLOQUE 3: Título principal ---
        JLabel lblTitulo = new JLabel("Aetas Historia");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Times New Roman", Font.BOLD, 36));
        lblTitulo.setBounds(247, 10, 300, 60);
        contentPane.add(lblTitulo);

        // --- BLOQUE 4: Botones de acciones principales ---

        // Añadir
        JButton btnAñadir = UIComponents.boton("Añadir Documento"); // REFACTORIZACIÓN
        btnAñadir.setBounds(29, 185, 166, 62); // REFACTORIZACIÓN
        btnAñadir.addActionListener(e -> {
            new DocumentCreationWindow(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnAñadir);

        // Actualizar
        JButton btnActualizar = UIComponents.boton("Actualizar Documento"); // REFACTORIZACIÓN
        btnActualizar.setBounds(205, 185, 195, 62); // REFACTORIZACIÓN
        btnActualizar.addActionListener(e -> {
            new DocumentListWindow(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnActualizar);

        // Eliminar
        JButton btnEliminar = UIComponents.boton("Eliminar Documento"); // REFACTORIZACIÓN
        btnEliminar.setBounds(410, 185, 183, 62); // REFACTORIZACIÓN
        btnEliminar.addActionListener(e -> {
            new DocumentListWindow(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnEliminar);

        // Buscar
        JButton btnBuscar = UIComponents.boton("Buscar Documento"); // REFACTORIZACIÓN
        btnBuscar.setBounds(603, 185, 158, 62); // REFACTORIZACIÓN
        btnBuscar.addActionListener(e -> {
            new DocumentListWindow(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnBuscar);

        // --- BLOQUE 5: Reordenar fondo al fondo visualmente ---
        contentPane.setComponentZOrder(fotoFondo, contentPane.getComponentCount() - 1);
    }

    // REFACTORIZACIÓN: Clase auxiliar para componentes comunes (botones)
    static class UIComponents {
        public static JButton boton(String texto) {
            JButton b = new JButton(texto);
            b.setForeground(Color.WHITE);
            b.setFont(new Font("Times New Roman", Font.BOLD, 16));
            b.setBackground(Color.GRAY);
            b.setFocusPainted(false);
            b.setBorderPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            return b;
        }
    }
}
