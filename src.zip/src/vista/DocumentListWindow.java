package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import modelo.ConexionMySQL;
import modelo.DocumentFullData;
import java.util.List;
import java.util.ArrayList;

/**
 * Ventana que muestra el listado de documentos con búsqueda en tiempo real,
 * permite eliminar documentos y navegar al detalle o volver al menú.
 */
public class DocumentListWindow extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel fotoFondo;

    // REFACTORIZACIÓN: listas como atributos de clase
    private DefaultListModel<String> model;
    private List<String> titulos;

    public DocumentListWindow(ConexionMySQL conexion) {
        setTitle("Aetas Historia - Documentos Registrados");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);

        contentPane = new JPanel(null);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(139, 69, 19));
        setContentPane(contentPane);

        // --- Fondo visual ---
        fotoFondo = new JLabel(new ImageIcon(getClass().getResource("/Fotos/biblioteca.png")));
        fotoFondo.setBounds(0, 0, getWidth(), getHeight());
        contentPane.add(fotoFondo);
        addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) {
                fotoFondo.setSize(getSize());
            }
        });

        // --- Título principal ---
        JLabel lblTitulo = new JLabel("Documentos Registrados");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Times New Roman", Font.BOLD, 36));
        lblTitulo.setBounds(180, 10, 440, 50);
        contentPane.add(lblTitulo);

        // --- Campo búsqueda ---
        JLabel lblBuscar = new JLabel("Buscar:");
        lblBuscar.setForeground(Color.WHITE);
        lblBuscar.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblBuscar.setBounds(10, 80, 80, 30);
        contentPane.add(lblBuscar);

        JTextField txtBuscar = new JTextField();
        txtBuscar.setBounds(100, 80, 500, 30);
        contentPane.add(txtBuscar);

        // --- Lista documentos ---
        model = new DefaultListModel<>();
        titulos = new ArrayList<>();
        JList<String> list = new JList<>(model);
        JScrollPane scroll = new JScrollPane(list);
        scroll.setBounds(10, 120, 780, 350);
        contentPane.add(scroll);

        // REFACTORIZACIÓN: carga separada en método auxiliar
        cargarDocumentos(conexion);

        // --- Búsqueda en tiempo real ---
        txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
            private void filtrar() {
                String filtro = txtBuscar.getText().trim().toLowerCase();
                model.clear();
                for (String t : titulos) {
                    if (t.toLowerCase().contains(filtro)) model.addElement(t);
                }
            }
            @Override public void insertUpdate(DocumentEvent e) { filtrar(); }
            @Override public void removeUpdate(DocumentEvent e) { filtrar(); }
            @Override public void changedUpdate(DocumentEvent e) { filtrar(); }
        });

        // --- Doble clic para ver detalle ---
        list.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    String sel = list.getSelectedValue();
                    DocumentFullData doc = conexion.getDocumentByTitle(sel);
                    new DocumentDetailWindow(conexion, doc).setVisible(true);
                    dispose();
                }
            }
        });

        // --- Botón Eliminar ---
        JButton btnEliminar = crearBoton("Eliminar", 650, 480, Color.RED);
        contentPane.add(btnEliminar);
        btnEliminar.addActionListener(e -> eliminarDocumento(list, conexion));

        // --- Botón Volver ---
        JButton btnVolver = crearBoton("Volver", 10, 480, Color.GRAY);
        contentPane.add(btnVolver);
        btnVolver.addActionListener(e -> {
            new MainMenuWindow(conexion).setVisible(true);
            dispose();
        });

        // Fondo al fondo visualmente
        contentPane.setComponentZOrder(fotoFondo, contentPane.getComponentCount() - 1);
    }

    // --- REFACTORIZACIÓN: Cargar títulos y modelo desde BD ---
    private void cargarDocumentos(ConexionMySQL conexion) {
        List<DocumentFullData> docs = conexion.getAllDocuments();
        for (DocumentFullData d : docs) {
            titulos.add(d.getTitulo());
            model.addElement(d.getTitulo());
        }
    }

    // --- REFACTORIZACIÓN: Estilo uniforme de botones ---
    private JButton crearBoton(String texto, int x, int y, Color fondo) {
        JButton b = new JButton(texto);
        b.setBounds(x, y, 120, 40);
        b.setForeground(Color.WHITE);
        b.setBackground(fondo);
        b.setFont(new Font("Times New Roman", Font.BOLD, 16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    // --- REFACTORIZACIÓN: Acción eliminar separada ---
    private void eliminarDocumento(JList<String> list, ConexionMySQL conexion) {
        String sel = list.getSelectedValue();
        if (sel == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un documento primero.");
            return;
        }

        int resp = JOptionPane.showConfirmDialog(
            this,
            "¿Eliminar '" + sel + "'?",
            "Confirmar eliminación",
            JOptionPane.YES_NO_OPTION
        );

        if (resp == JOptionPane.YES_OPTION) {
            if (conexion.deleteDocument(sel)) {
                JOptionPane.showMessageDialog(this, "Documento eliminado.");
                model.removeElement(sel);
                titulos.remove(sel);
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar.");
            }
        }
    }
}
