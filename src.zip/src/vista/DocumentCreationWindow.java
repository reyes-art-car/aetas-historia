package vista;

import java.awt.*;
import java.awt.event.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import modelo.ConexionMySQL;

/**
 * Ventana para crear (subir) un nuevo documento.
 */
public class DocumentCreationWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    /** Conexión a la base de datos */
    private final ConexionMySQL conexion;
    /** Panel principal con layout absoluto */
    private JPanel contentPane;
    /** Campos de texto para metadatos del documento */
    private JTextField txtTitulo, txtAutor, txtDescripcion,
                       txtAnio, txtColeccion, txtFormato,
                       txtImagenPath;
    /** Etiqueta que mostrará la imagen de fondo */
    private JLabel fotoFondo;

    /**
     * Constructor.
     * @param conexion instancia de conexión a la base de datos
     */
    public DocumentCreationWindow(ConexionMySQL conexion) {
        this.conexion = conexion;

        // --- BLOQUE 1: Configuración de ventana y panel ---
        setTitle("Aetas Historia - Añadir Documento");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 480);

        contentPane = new JPanel(null);
        contentPane.setBorder(new EmptyBorder(5,5,5,5));
        setContentPane(contentPane);

        // --- BLOQUE 2: Fondo visual (añadido primero para enviarlo al fondo luego) ---
        ImageIcon fondoIcon = new ImageIcon(
            getClass().getResource("/Fotos/biblioteca.png")
        );
        fotoFondo = new JLabel(fondoIcon);
        fotoFondo.setBounds(0, 0, getWidth(), getHeight());
        contentPane.add(fotoFondo);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                fotoFondo.setSize(getSize());
            }
        });

        // --- BLOQUE 3: Etiquetas visibles (orden visual de arriba hacia abajo) ---
        addLabel("Nombre del documento", 10, 168);
        addLabel("Nombre del Autor",     10, 204);
        addLabel("Descripción",          10, 243);
        addLabel("Año",                  10, 274);
        addLabel("Colección",            10, 313);
        addLabel("Formato",              10, 355);
        addLabel("Imagen (.png/.jpg)",   10, 395);

        // --- BLOQUE 4: Campos de texto (alineados a la derecha de las etiquetas) ---
        txtTitulo      = addTF(354, 191);
        txtAutor       = addTF(354, 227);
        txtDescripcion = addTF(354, 266);
        txtAnio        = addTF(354, 297);
        txtColeccion   = addTF(354, 336);
        txtFormato     = addTF(354, 380);
        txtImagenPath  = addTF(354, 415);
        txtImagenPath.setEditable(false);

        // --- BLOQUE 5: Botón para seleccionar imagen ---
        JButton btnImagen = makeButton("Seleccionar Imagen", 600, 412);
        contentPane.add(btnImagen);
        btnImagen.addActionListener(e -> {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                txtImagenPath.setText(chooser.getSelectedFile().getAbsolutePath());
            }
        });

        // --- BLOQUE 6: Botón para crear documento ---
        JButton btnCrear = makeButton("Crear Documento", 600, 350);
        contentPane.add(btnCrear);
        btnCrear.addActionListener(e -> {
            // --- BLOQUE 6.1: Recolectar datos del formulario ---
            String titulo      = txtTitulo.getText().trim();
            String autor       = txtAutor.getText().trim();
            String descripcion = txtDescripcion.getText().trim();
            String anioStr     = txtAnio.getText().trim();
            String coleccion   = txtColeccion.getText().trim();
            String formato     = txtFormato.getText().trim();
            String imagenPath  = txtImagenPath.getText().trim();

            // --- BLOQUE 6.2: Validación del año ---
            int anio;
            try {
                anio = Integer.parseInt(anioStr);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "El campo Año debe ser numérico.");
                return;
            }

            // --- BLOQUE 6.3: Fecha y hora actual ---
            String fechaHora = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            // --- BLOQUE 6.4: Intento de guardar en base de datos ---
            boolean ok = conexion.añadirDocumento(
                titulo, descripcion, autor, anio,
                formato, coleccion, fechaHora,
                imagenPath
            );

            if (!ok) {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el documento.");
                return;
            }

            // --- BLOQUE 6.5: Si fue exitoso, ir al listado ---
            new DocumentListWindow(conexion).setVisible(true);
            dispose();
        });

        // Enter activa el botón "Crear Documento"
        getRootPane().setDefaultButton(btnCrear);

        // Fondo al fondo visualmente
        contentPane.setComponentZOrder(fotoFondo, contentPane.getComponentCount() - 1);
    }

    // --- BLOQUE 7: Métodos auxiliares de interfaz ---

    /** Crea y añade una JLabel con estilo */
    private void addLabel(String text, int x, int y) {
        JLabel lbl = new JLabel(text);
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lbl.setBounds(x, y, 300, 30);
        contentPane.add(lbl);
    }

    /** Crea y añade un JTextField */
    private JTextField addTF(int x, int y) {
        JTextField tf = new JTextField();
        tf.setBounds(x, y, 226, 19);
        contentPane.add(tf);
        return tf;
    }

    /** Crea un JButton con estilo uniforme */
    private JButton makeButton(String txt, int x, int y) {
        JButton b = new JButton(txt);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Times New Roman", Font.BOLD, 16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setBorderPainted(false);
        b.setBackground(Color.GRAY);
        b.setBounds(x, y, 158, 38);
        return b;
    }
}
