package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import modelo.ConexionMySQL;

/**
 * Ventana para registrar un investigador,
 * llamada desde ResearcherLoginWindow.
 */
public class RegistroInvestigador extends JFrame {

    private static final long serialVersionUID = 1L;
    private final ConexionMySQL conexion;
    private JPanel contentPane;
    private JTextField rellenar_Nombre;
    private JTextField rellenar_Apellidos;
    private JTextField rellenar_CorreoElectronico;

    /**
     * Constructor.
     * @param conexion instancia de conexión a la BD
     */
    public RegistroInvestigador(ConexionMySQL conexion) {
        this.conexion = conexion;

        // --- BLOQUE 1: Configuración de ventana y panel principal ---
        setTitle("Aetas Historia - Registro Investigador");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 440);

        contentPane = new JPanel(null);
        contentPane.setBackground(new Color(139, 69, 19));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        // --- BLOQUE 2: Fondo visual (reordenado al fondo luego) ---
        JLabel fotoFondo = new JLabel(new ImageIcon(
            getClass().getResource("/Fotos/biblioteca.png")
        ));
        fotoFondo.setBounds(-122, -9, 903, 584);
        contentPane.add(fotoFondo);

        // --- BLOQUE 3: Títulos principales ---
        JLabel lblTitulo1 = new JLabel("Aetas Historia");
        lblTitulo1.setForeground(Color.WHITE);
        lblTitulo1.setFont(new Font("Times New Roman", Font.BOLD, 36));
        lblTitulo1.setBounds(223, 10, 300, 60);
        contentPane.add(lblTitulo1);

        JLabel lblTitulo2 = new JLabel("Regístrate Investigador");
        lblTitulo2.setForeground(Color.WHITE);
        lblTitulo2.setFont(new Font("Times New Roman", Font.BOLD, 28));
        lblTitulo2.setBounds(200, 66, 400, 60);
        contentPane.add(lblTitulo2);

        // --- BLOQUE 4: Etiquetas y campos de texto ---

        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setForeground(Color.WHITE);
        lblNombre.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblNombre.setBounds(10, 148, 150, 30);
        contentPane.add(lblNombre);

        rellenar_Nombre = new JTextField();
        rellenar_Nombre.setBounds(170, 148, 415, 30);
        contentPane.add(rellenar_Nombre);

        JLabel lblApellidos = new JLabel("Apellidos:");
        lblApellidos.setForeground(Color.WHITE);
        lblApellidos.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblApellidos.setBounds(10, 200, 150, 30);
        contentPane.add(lblApellidos);

        rellenar_Apellidos = new JTextField();
        rellenar_Apellidos.setBounds(170, 200, 415, 30);
        contentPane.add(rellenar_Apellidos);

        JLabel lblCorreo = new JLabel("Correo Electrónico:");
        lblCorreo.setForeground(Color.WHITE);
        lblCorreo.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblCorreo.setBounds(10, 252, 180, 30);
        contentPane.add(lblCorreo);

        rellenar_CorreoElectronico = new JTextField();
        rellenar_CorreoElectronico.setBounds(200, 252, 385, 30);
        contentPane.add(rellenar_CorreoElectronico);

        // --- BLOQUE 5: Botón de registro ---
        JButton btnRegistrate = UIComponents.boton("Regístrate"); // REFACTORIZACIÓN
        btnRegistrate.setBounds(298, 317, 145, 62); // REFACTORIZACIÓN
        contentPane.add(btnRegistrate);

        btnRegistrate.addActionListener(e -> {
            // Aquí podrías validar y guardar datos en la BD usando `conexion`
            new MainMenuWindow(conexion).setVisible(true);
            dispose();
        });

        // --- BLOQUE 6: Asegurar fondo detrás de todo ---
        contentPane.setComponentZOrder(fotoFondo, contentPane.getComponentCount() - 1);
    }

    // REFACTORIZACIÓN: Clase auxiliar para crear botones con estilo común
    static class UIComponents {
        public static JButton boton(String texto) {
            JButton b = new JButton(texto);
            b.setForeground(Color.WHITE);
            b.setFont(new Font("Times New Roman", Font.BOLD, 16));
            b.setBackground(Color.GRAY);
            b.setFocusPainted(false);
            b.setBorderPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            return b;
        }
    }
}
