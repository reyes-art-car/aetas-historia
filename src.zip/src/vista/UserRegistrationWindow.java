package vista;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import modelo.ConexionMySQL;

/**
 * Panel de administración: desde aquí el administrador puede
 * registrarse, iniciar sesión o volver al menú principal.
 */
public class UserRegistrationWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    /** Conexión a la base de datos recibida desde HomeWindow */
    private final ConexionMySQL conexion;
    /** Panel principal donde se colocan todos los componentes Swing */
    private JPanel contentPane;

    /**
     * Constructor.
     * @param conexion Instancia de conexión a la base de datos
     */
    public UserRegistrationWindow(ConexionMySQL conexion) {
        this.conexion = conexion;
        configurarVentana();     // REFACTORIZACION: configuración ventana separada
        inicializarComponentes(); // REFACTORIZACION: creación componentes UI separada
    }

    // REFACTORIZACION: método para configurar ventana y panel principal
    private void configurarVentana() {
        setTitle("Aetas Historia - Administrador");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 786, 442);

        contentPane = new JPanel(null);
        contentPane.setBackground(new Color(139, 69, 19));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
    }

    // REFACTORIZACION: método para crear e inicializar los componentes UI
    private void inicializarComponentes() {
        // Imagen de fondo (última visualmente)
        JLabel fotoFondo = new JLabel(
            new ImageIcon(getClass().getResource("/Fotos/biblioteca.png"))
        );
        fotoFondo.setBounds(-118, -34, 929, 666);
        contentPane.add(fotoFondo);

        // Imagen decorativa (arriba a la izquierda)
        ImageIcon iconoOriginal = new ImageIcon(
            getClass().getResource("/Fotos/administrador.png")
        );
        Image imgRed = iconoOriginal.getImage()
            .getScaledInstance(150, 160, Image.SCALE_SMOOTH);
        JLabel foto1 = new JLabel(new ImageIcon(imgRed));
        foto1.setBounds(95, 10, 150, 160);
        foto1.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(foto1);

        // Títulos principales (centrados arriba)
        JLabel titulo1 = new JLabel("Aetas Historia");
        titulo1.setForeground(Color.WHITE);
        titulo1.setFont(new Font("Times New Roman", Font.BOLD, 36));
        titulo1.setBounds(253, 10, 300, 60);
        contentPane.add(titulo1);

        JLabel titulo2 = new JLabel("Administrador");
        titulo2.setForeground(Color.WHITE);
        titulo2.setFont(new Font("Times New Roman", Font.BOLD, 36));
        titulo2.setBounds(253, 80, 300, 60);
        contentPane.add(titulo2);

        // Botón “Regístrate”
        JButton btnRegistrate = new JButton("Regístrate");
        aplicarEstiloBoton(btnRegistrate);
        btnRegistrate.setBounds(291, 169, 145, 62);
        btnRegistrate.addActionListener(e -> {
            new UserRegistrationWindow(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnRegistrate);

        // Botón “Accede”
        JButton btnAccede = new JButton("Accede");
        aplicarEstiloBoton(btnAccede);
        btnAccede.setBounds(291, 267, 145, 62);
        btnAccede.addActionListener(e -> {
            new LoginWindow(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnAccede);

        // Botón “Retroceso”
        JButton btnRetroceso = new JButton("Retroceso");
        aplicarEstiloBoton(btnRetroceso);
        btnRetroceso.setBounds(10, 332, 139, 62);
        btnRetroceso.addActionListener(e -> {
            new HomeWindow(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnRetroceso);

        // Asegurar que el fondo esté al fondo
        contentPane.setComponentZOrder(fotoFondo, contentPane.getComponentCount() - 1);
    }

    // Método auxiliar para aplicar estilo a los botones
    private void aplicarEstiloBoton(JButton b) {
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Times New Roman", Font.BOLD, 16));
        b.setBackground(Color.GRAY);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }
}
