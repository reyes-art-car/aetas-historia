package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import modelo.ConexionMySQL;
import modelo.Usuario;  // Asumo que tienes esta clase con métodos de validación y usuario

/**
 * Ventana para registrar un nuevo usuario.
 */
public class AdminDashboardWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    /** Conexión a la base de datos heredada desde HomeWindow */
    private final ConexionMySQL conexion;
    private JPanel contentPane;
    private JTextField txtUsuario;
    private JPasswordField txtPassword;
    private JTextField txtCorreoElectronico;

    /**
     * Constructor.
     * @param conexion Instancia de conexión a la base de datos
     */
    public AdminDashboardWindow(ConexionMySQL conexion) {
        this.conexion = conexion;

        // --- Configuración básica de la ventana ---
        setTitle("Aetas Historia - Registro");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 440);

        contentPane = new JPanel(null);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(139, 69, 19));
        setContentPane(contentPane);

        // --- Fondo visual ---
        JLabel fotoFondo = new JLabel(new ImageIcon(
            getClass().getResource("/Fotos/biblioteca.png")
        ));
        fotoFondo.setBounds(-122, -9, 903, 584);
        contentPane.add(fotoFondo);

        // --- Títulos ---
        JLabel titulo1 = new JLabel("Aetas Historia");
        titulo1.setForeground(Color.WHITE);
        titulo1.setFont(new Font("Times New Roman", Font.BOLD, 36));
        titulo1.setBounds(246, 22, 300, 60);
        contentPane.add(titulo1);

        JLabel titulo2 = new JLabel("Regístrate");
        titulo2.setForeground(Color.WHITE);
        titulo2.setFont(new Font("Times New Roman", Font.BOLD, 36));
        titulo2.setBounds(275, 78, 300, 60);
        contentPane.add(titulo2);

        // --- Etiquetas ---
        JLabel lblUsuario = new JLabel("Usuario");
        lblUsuario.setForeground(Color.WHITE);
        lblUsuario.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblUsuario.setBounds(43, 134, 100, 60);
        contentPane.add(lblUsuario);

        JLabel lblContrasena = new JLabel("Contraseña");
        lblContrasena.setForeground(Color.WHITE);
        lblContrasena.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblContrasena.setBounds(43, 194, 120, 60);
        contentPane.add(lblContrasena);

        JLabel lblCorreo = new JLabel("Correo Electrónico");
        lblCorreo.setForeground(Color.WHITE);
        lblCorreo.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblCorreo.setBounds(0, 246, 169, 60);
        contentPane.add(lblCorreo);

        // --- Campos de entrada ---
        txtUsuario = new JTextField();
        txtUsuario.setBounds(178, 148, 359, 37);
        contentPane.add(txtUsuario);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(178, 205, 359, 37);
        contentPane.add(txtPassword);

        txtCorreoElectronico = new JTextField();
        txtCorreoElectronico.setBounds(179, 260, 359, 37);
        contentPane.add(txtCorreoElectronico);

        // --- Botón "Regístrate" ---
        JButton btnRegistrate = new JButton("Regístrate");
        btnRegistrate.setForeground(Color.WHITE);
        btnRegistrate.setFont(new Font("Times New Roman", Font.BOLD, 16));
        btnRegistrate.setBackground(Color.GRAY);
        btnRegistrate.setFocusPainted(false);
        btnRegistrate.setBorderPainted(false);
        btnRegistrate.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRegistrate.setBounds(298, 317, 145, 62);
        contentPane.add(btnRegistrate);

        // --- Lógica del botón ---
        btnRegistrate.addActionListener(e -> {
            String usuario = txtUsuario.getText().trim();
            String password = new String(txtPassword.getPassword()).trim();
            String email = txtCorreoElectronico.getText().trim();

            if (usuario.isEmpty() || password.isEmpty() || email.isEmpty()) {
                JOptionPane.showMessageDialog(
                    this,
                    "Por favor, rellena todos los campos.",
                    "Datos inválidos",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            if (!email.contains("@")) {
                JOptionPane.showMessageDialog(
                    this,
                    "El correo debe contener '@'.",
                    "Error en correo",
                    JOptionPane.ERROR_MESSAGE
                );
                return;
            }

            // Aquí uso el método estático validator de Usuario, debe existir en tu modelo
            if (Usuario.validator(usuario, password, email)) {
                if (!conexion.userExist(usuario)) {
                    boolean registrado = conexion.register(usuario, email, password);
                    if (registrado) {
                        JOptionPane.showMessageDialog(
                            this,
                            "Usuario registrado correctamente.",
                            "Registro exitoso",
                            JOptionPane.INFORMATION_MESSAGE
                        );
                        new MainMenuWindow(conexion).setVisible(true);
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(
                            this,
                            "Error al registrar el usuario.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                        );
                    }
                } else {
                    JOptionPane.showMessageDialog(
                        this,
                        "El usuario ya existe.",
                        "Error de registro",
                        JOptionPane.ERROR_MESSAGE
                    );
                }
            } else {
                JOptionPane.showMessageDialog(
                    this,
                    "Los datos no cumplen los requisitos.",
                    "Datos inválidos",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        });

        // --- Fondo al fondo visual ---
        contentPane.setComponentZOrder(fotoFondo, contentPane.getComponentCount() - 1);
    }
}
