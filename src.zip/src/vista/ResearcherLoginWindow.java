package vista;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import modelo.ConexionMySQL;

/**
 * Ventana de login / acceso para investigadores.
 */
public class ResearcherLoginWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    /** Conexión a la base de datos recibida desde HomeWindow */
    private final ConexionMySQL conexion;
    private JPanel contentPane;

    /**
     * Constructor.
     * @param conexion Instancia de conexión a la BD
     */
    public ResearcherLoginWindow(ConexionMySQL conexion) {
        this.conexion = conexion;

        // --- BLOQUE 1: Configuración de ventana y panel principal ---
        setTitle("Aetas Historia - Investigador");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 440);

        contentPane = new JPanel(null);
        contentPane.setBackground(new Color(139, 69, 19));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        // --- BLOQUE 2: Imagen de fondo (se reordena al fondo luego) ---
        JLabel fotoFondo = new JLabel(new ImageIcon(
            getClass().getResource("/Fotos/biblioteca.png")
        ));
        fotoFondo.setBounds(-112, 0, 902, 558);
        contentPane.add(fotoFondo);

        // --- BLOQUE 3: Títulos principales ---
        JLabel lblTitulo1 = new JLabel("Aetas Historia");
        lblTitulo1.setForeground(Color.WHITE);
        lblTitulo1.setFont(new Font("Times New Roman", Font.BOLD, 36));
        lblTitulo1.setBounds(248, 10, 300, 60);
        contentPane.add(lblTitulo1);

        JLabel lblTitulo2 = new JLabel("Investigador");
        lblTitulo2.setForeground(Color.WHITE);
        lblTitulo2.setFont(new Font("Times New Roman", Font.BOLD, 36));
        lblTitulo2.setBounds(263, 64, 300, 60);
        contentPane.add(lblTitulo2);

        // --- BLOQUE 4: Botones de acción ---

        // Botón "Regístrate"
        JButton btnRegistrate = UIComponents.boton("Regístrate"); // REFACTORIZACIÓN
        btnRegistrate.setBounds(288, 165, 158, 38); // REFACTORIZACIÓN
        btnRegistrate.addActionListener(e -> {
            new RegistroInvestigador(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnRegistrate);

        // Botón "Accede"
        JButton btnAccede = UIComponents.boton("Accede con tu correo de usuario"); // REFACTORIZACIÓN
        btnAccede.setBounds(226, 257, 282, 51); // REFACTORIZACIÓN
        btnAccede.addActionListener(e -> {
            new LoginWindow(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnAccede);

        // --- BLOQUE 5: Reordenar fondo al fondo visualmente ---
        contentPane.setComponentZOrder(fotoFondo, contentPane.getComponentCount() - 1);
    }

    // REFACTORIZACIÓN: Clase auxiliar para crear botones con estilo común
    static class UIComponents {
        public static JButton boton(String texto) {
            JButton b = new JButton(texto);
            b.setForeground(Color.WHITE);
            b.setFont(new Font("Times New Roman", Font.BOLD, 16));
            b.setBackground(Color.GRAY);
            b.setFocusPainted(false);
            b.setBorderPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            return b;
        }
    }
}
