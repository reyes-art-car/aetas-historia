package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import modelo.ConexionMySQL;
import modelo.DocumentFullData;

/**
 * Visor y editor de un documento individual.
 */
public class DocumentDetailWindow extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JLabel fotoFondo;

    /**
     * Constructor para visitante sin logeo (solo muestra mensaje).
     */
    public DocumentDetailWindow() {
        this(null, null);
    }

    /**
     * Constructor que recibe el documento completo y la conexión para editarlo.
     * @param conexion Conexión a la base de datos
     * @param doc Datos completos del documento
     */
    public DocumentDetailWindow(ConexionMySQL conexion, DocumentFullData doc) {
        setTitle(doc != null ? doc.getTitulo() : "Visor de Documento");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 550);

        contentPane = new JPanel(null);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(new Color(139, 69, 19));
        setContentPane(contentPane);

        // Fondo
        ImageIcon fondoIcon = new ImageIcon(getClass().getResource("/Fotos/biblioteca.png"));
        fotoFondo = new JLabel(fondoIcon);
        fotoFondo.setBounds(0, 0, getWidth(), getHeight());
        contentPane.add(fotoFondo);
        addComponentListener(new ComponentAdapter() {
            @Override public void componentResized(ComponentEvent e) {
                fotoFondo.setSize(getSize());
            }
        });

        if (doc != null) {
            // --- BLOQUE 3: Mostrar datos del documento ---
            // REFACTORIZACIÓN: uso de método auxiliar para crear etiquetas

            addLabel("Título:", 30, 20);
            addValue(doc.getTitulo(), 140, 20);

            addLabel("Autor:", 30, 60);
            addValue(doc.getAutor(), 140, 60);

            addLabel("Descripción:", 30, 100);
            JTextArea valDesc = new JTextArea(doc.getDescripcion());
            valDesc.setForeground(Color.WHITE);
            valDesc.setBackground(new Color(0, 0, 0, 80));
            valDesc.setFont(new Font("Times New Roman", Font.PLAIN, 14));
            valDesc.setLineWrap(true);
            valDesc.setWrapStyleWord(true);
            valDesc.setEditable(false);
            JScrollPane scrollDesc = new JScrollPane(valDesc);
            scrollDesc.setBounds(140, 100, 600, 100);
            contentPane.add(scrollDesc);

            addLabel("Año:", 30, 220);
            addValue(String.valueOf(doc.getAnio()), 140, 220);

            addLabel("Formato:", 30, 260);
            addValue(doc.getFormato(), 140, 260);

            addLabel("Colección:", 30, 300);
            addValue(doc.getColeccion(), 140, 300);

            addLabel("Fecha subida:", 30, 340);
            addValue(doc.getFechaDeSubida(), 170, 340);

            // Imagen
            String imgPath = doc.getImagenPath();
            if (imgPath != null && !imgPath.isBlank()) {
                ImageIcon icon = new ImageIcon(imgPath);
                Image img = icon.getImage().getScaledInstance(200, 200, Image.SCALE_SMOOTH);
                JLabel lblImg = new JLabel(new ImageIcon(img));
                lblImg.setBounds(550, 220, 200, 200);
                contentPane.add(lblImg);
            }
        } else {
            // Usuario visitante
            JLabel lblVis = new JLabel("Bienvenido, visitante sin logeo");
            lblVis.setForeground(Color.WHITE);
            lblVis.setFont(new Font("Times New Roman", Font.BOLD, 24));
            lblVis.setBounds(200, 200, 400, 50);
            contentPane.add(lblVis);
        }

        // Botón volver
        JButton btnVolver = new JButton("Volver");
        btnVolver.setForeground(Color.WHITE);
        btnVolver.setBackground(Color.GRAY);
        btnVolver.setFont(new Font("Times New Roman", Font.BOLD, 16));
        btnVolver.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnVolver.setBounds(600, 420, 158, 38);
        btnVolver.addActionListener(e -> {
            new DocumentListWindow(conexion).setVisible(true);
            dispose();
        });
        contentPane.add(btnVolver);

        // Fondo al fondo
        contentPane.setComponentZOrder(fotoFondo, contentPane.getComponentCount() - 1);
    }

    // --- REFACTORIZACIÓN: método auxiliar para etiquetas ---
    private void addLabel(String texto, int x, int y) {
        JLabel lbl = new JLabel(texto);
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lbl.setBounds(x, y, 140, 30);
        contentPane.add(lbl);
    }

    // --- REFACTORIZACIÓN: método auxiliar para valores de texto ---
    private void addValue(String valor, int x, int y) {
        JLabel val = new JLabel(valor);
        val.setForeground(Color.WHITE);
        val.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        val.setBounds(x, y, 600, 30);
        contentPane.add(val);
    }
}
