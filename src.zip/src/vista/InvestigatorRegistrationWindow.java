package vista;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

/**
 * Ventana para registrar un nuevo investigador.
 */
public class InvestigatorRegistrationWindow extends JFrame {

    private static final long serialVersionUID = 1L;

    /** Panel principal donde van todos los componentes */
    private JPanel contentPane;
    /** Campo de texto para el nombre */
    private JTextField txtNombre;
    /** Campo de texto para los apellidos */
    private JTextField txtApellidos;
    /** Campo de texto para el correo electrónico */
    private JTextField txtCorreo;

    /**
     * Constructor.
     * Monta la interfaz para que un investigador introduzca sus datos.
     */
    public InvestigatorRegistrationWindow() {
        // --- BLOQUE 1: Configuración básica de la ventana y panel ---
        setTitle("Aetas Historia - Registro Investigador");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 785, 440);

        contentPane = new JPanel(null);
        contentPane.setBackground(new Color(139, 69, 19));
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        // --- BLOQUE 2: Fondo visual (se añadirá al fondo visualmente luego) ---
        JLabel fotoFondo = new JLabel(new ImageIcon(
            getClass().getResource("/Fotos/biblioteca.png")
        ));
        fotoFondo.setBounds(-152, -3, 939, 558);
        contentPane.add(fotoFondo);

        // --- BLOQUE 3: Títulos principales ---
        JLabel lblTitulo1 = new JLabel("Aetas Historia");
        lblTitulo1.setForeground(Color.WHITE);
        lblTitulo1.setFont(new Font("Times New Roman", Font.BOLD, 36));
        lblTitulo1.setBounds(223, 10, 300, 60);
        contentPane.add(lblTitulo1);

        JLabel lblTitulo2 = new JLabel("Registro Investigador");
        lblTitulo2.setForeground(Color.WHITE);
        lblTitulo2.setFont(new Font("Times New Roman", Font.BOLD, 28));
        lblTitulo2.setBounds(230, 66, 350, 60);
        contentPane.add(lblTitulo2);

        // --- BLOQUE 4: Etiquetas de los campos ---
        JLabel lblNombre = new JLabel("Nombre:");
        lblNombre.setForeground(Color.WHITE);
        lblNombre.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblNombre.setBounds(10, 148, 150, 60);
        contentPane.add(lblNombre);

        JLabel lblApellidos = new JLabel("Apellidos:");
        lblApellidos.setForeground(Color.WHITE);
        lblApellidos.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblApellidos.setBounds(10, 206, 150, 60);
        contentPane.add(lblApellidos);

        JLabel lblCorreo = new JLabel("Correo Electrónico:");
        lblCorreo.setForeground(Color.WHITE);
        lblCorreo.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblCorreo.setBounds(10, 261, 200, 60);
        contentPane.add(lblCorreo);

        // --- BLOQUE 5: Campos de texto para introducir datos ---
        txtNombre = new JTextField();
        txtNombre.setBounds(220, 163, 450, 27);
        contentPane.add(txtNombre);

        txtApellidos = new JTextField();
        txtApellidos.setBounds(220, 206, 450, 27);
        contentPane.add(txtApellidos);

        txtCorreo = new JTextField();
        txtCorreo.setBounds(220, 263, 450, 27);
        contentPane.add(txtCorreo);

        // --- BLOQUE 6: Asegurar que el fondo quede al fondo visual ---
        contentPane.setComponentZOrder(fotoFondo, contentPane.getComponentCount() - 1);
    }

    // REFACTORIZACIÓN: Clase auxiliar para componentes comunes (botones, etc)
    static class UIComponents {
        public static JButton boton(String texto) {
            JButton b = new JButton(texto);
            b.setForeground(Color.WHITE);
            b.setFont(new Font("Times New Roman", Font.BOLD, 16));
            b.setBackground(new Color(128, 128, 128));
            b.setFocusPainted(false);
            b.setBorderPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            return b;
        }
    }
}
