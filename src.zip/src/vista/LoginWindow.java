package vista;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import modelo.ConexionMySQL;

/**
 * Ventana de login genérico: comprueba usuario y contraseña contra la BD.
 */
public class LoginWindow extends JFrame {
    private static final long serialVersionUID = 1L;

    /** Conexión a la base de datos MySQL */
    private final ConexionMySQL conexion;
    /** Panel principal donde se colocan todos los componentes */
    private JPanel contentPane;
    /** Campo de texto para el nombre de usuario */
    private JTextField txtUsuario;
    /** Campo de texto para la contraseña */
    private JPasswordField txtPassword;

    /**
     * Constructor.
     * @param conexion Instancia de conexión a la base de datos
     */
    public LoginWindow(ConexionMySQL conexion) {
        this.conexion = conexion;

        // --- BLOQUE 1: Configuración básica de la ventana y panel ---
        setTitle("Aetas Historia - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 370);

        contentPane = new JPanel(null);
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);

        // --- BLOQUE 2: Fondo visual (reordenado al fondo más adelante) ---
        ImageIcon fondoIcon = new ImageIcon(getClass().getResource("/Fotos/biblioteca.png"));
        JLabel fondo = new JLabel(fondoIcon);
        fondo.setBounds(0, 0, getWidth(), getHeight());
        contentPane.add(fondo);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                fondo.setSize(getSize());
            }
        });

        // --- BLOQUE 3: Etiquetas y campos de entrada ---

        // Usuario
        JLabel lblUsuario = new JLabel("Usuario:");
        lblUsuario.setForeground(Color.WHITE);
        lblUsuario.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblUsuario.setBounds(100, 100, 100, 30);
        contentPane.add(lblUsuario);

        txtUsuario = new JTextField();
        txtUsuario.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        txtUsuario.setBounds(210, 100, 200, 30);
        contentPane.add(txtUsuario);

        // Contraseña
        JLabel lblPassword = new JLabel("Contraseña:");
        lblPassword.setForeground(Color.WHITE);
        lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 18));
        lblPassword.setBounds(100, 150, 100, 30);
        contentPane.add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Times New Roman", Font.PLAIN, 16));
        txtPassword.setBounds(210, 150, 200, 30);
        contentPane.add(txtPassword);

        // --- BLOQUE 4: Botón Entrar (REFACTORIZACIÓN) ---
        JButton btnEntrar = UIComponents.boton("Entrar");
        btnEntrar.setBounds(210, 210, 100, 35);
        contentPane.add(btnEntrar);

        // Enter activa el botón
        getRootPane().setDefaultButton(btnEntrar);

        // --- BLOQUE 5: Acción del botón Entrar ---
        btnEntrar.addActionListener(e -> {
            String user = txtUsuario.getText().trim();
            String pass = new String(txtPassword.getPassword());

            if (conexion.logging(user, pass)) {
                JOptionPane.showMessageDialog(this, "¡Login exitoso!");
                new MainMenuWindow(conexion).setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(
                    this,
                    "Usuario o contraseña incorrectos.",
                    "Error de login",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        });

        // --- BLOQUE 6: Fondo al fondo visualmente ---
        contentPane.setComponentZOrder(fondo, contentPane.getComponentCount() - 1);
    }

    // REFACTORIZACIÓN: Clase auxiliar para componentes comunes (botones)
    static class UIComponents {
        public static JButton boton(String texto) {
            JButton b = new JButton(texto);
            b.setForeground(Color.WHITE);
            b.setFont(new Font("Times New Roman", Font.BOLD, 16));
            b.setBackground(Color.GRAY);
            b.setFocusPainted(false);
            b.setBorderPainted(false);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            return b;
        }
    }
}
