package test;

import modelo.Usuario;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UsuarioTest {

    @Test
    void testGettersAndSetters() {
        Usuario user = new Usuario();
        user.setNombre("Juan");
        user.setEmail("juan@example.com");
        user.setId_tipo_de_usuario("Administrador");

        assertEquals("Juan", user.getNombre());
        assertEquals("juan@example.com", user.getEmail());
        assertEquals("Administrador", user.getId_tipo_de_usuario());
    }

    @Test
    void testToString() {
        Usuario user = new Usuario();
        user.setNombre("Ana");
        user.setEmail("ana@example.com");
        user.setId_tipo_de_usuario("Investigador");

        String expected = "Usuario [nombre=Ana, email=ana@example.com, id_tipo_de_usuario=Investigador]";
        assertEquals(expected, user.toString());
    }

}
