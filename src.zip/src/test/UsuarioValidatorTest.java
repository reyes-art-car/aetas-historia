package test;

import modelo.Usuario;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UsuarioValidatorTest {

    @Test
    void testValidator_validInput() {
        assertTrue(Usuario.validator("Juan", "1234", "juan@example.com"));
    }

    @Test
    void testValidator_invalidInput() {
        assertFalse(Usuario.validator("", "1234", "juan@example.com"));
        assertFalse(Usuario.validator("Juan", null, "juan@example.com"));
    }

    @Test
    void testValidatorWithNullEmail() {
        // Aunque el validador no evalúa el email, aseguramos que no lanza excepción si es null
        assertTrue(Usuario.validator("Ana", "claveSegura", null));
    }

}
